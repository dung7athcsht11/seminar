import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from peft import LoraConfig, get_peft_model
from sklearn.metrics import accuracy_score, f1_score
import pandas as pd
from torch.utils.data import DataLoader, Dataset

# 1. Định nghĩa dữ liệu mẫu (Instruction Tuning)
data = [
    {"instruction": "What is the sentiment of this news? Please choose an answer from {negative/neutral/positive}.",
     "input": "The company reported a significant profit increase this quarter.",
     "output": "positive"},
    {"instruction": "What is the sentiment of this news? Please choose an answer from {negative/neutral/positive}.",
     "input": "The stock market crashed due to economic uncertainty.",
     "output": "negative"},
    {"instruction": "What is the sentiment of this news? Please choose an answer from {negative/neutral/positive}.",
     "input": "The firm's revenue remained stable this year.",
     "output": "neutral"},
]

# 2. Định dạng dữ liệu thành prompt (Instruction Tuning)
def format_example(example):
    context = f"Instruction: {example['instruction']}\nInput: {example['input']}\nAnswer: "
    target = example["output"]
    return {"context": context, "target": target}

# Chuyển đổi dữ liệu thành định dạng prompt
df = pd.DataFrame(data)
df[["context", "target"]] = df.apply(format_example, axis=1, result_type="expand")

# 3. Chuẩn hóa nhãn
def change_target(x):
    if 'positive' in x.lower():
        return 'positive'
    elif 'negative' in x.lower():
        return 'negative'
    else:
        return 'neutral'

# 4. Tạo dataset PyTorch
class SentimentDataset(Dataset):
    def __init__(self, contexts, targets, tokenizer, max_length):
        self.contexts = contexts
        self.targets = targets
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.label_map = {"negative": 0, "neutral": 1, "positive": 2}

    def __len__(self):
        return len(self.contexts)

    def __getitem__(self, idx):
        context = self.contexts[idx]
        target = self.targets[idx]
        encoding = self.tokenizer(
            context,
            return_tensors="pt",
            padding="max_length",
            truncation=True,
            max_length=self.max_length
        )
        label = self.label_map[target]
        return {
            "input_ids": encoding["input_ids"].squeeze(),
            "attention_mask": encoding["attention_mask"].squeeze(),
            "labels": torch.tensor(label, dtype=torch.long)
        }

# 5. Tải mô hình và tokenizer
model_name = "distilbert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(
    model_name,
    num_labels=3  # negative, neutral, positive
)

# 6. Áp dụng LoRA
lora_config = LoraConfig(
    task_type="SEQ_CLS",
    r=8,
    lora_alpha=32,
    lora_dropout=0.1,
    target_modules=["q_lin", "v_lin"],  # DistilBERT modules for LoRA
)
model = get_peft_model(model, lora_config)

# 7. Chuẩn bị dữ liệu huấn luyện
train_dataset = SentimentDataset(
    df["context"].tolist(),
    df["target"].apply(change_target).tolist(),
    tokenizer,
    max_length=128
)
train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True)

# 8. Huấn luyện mô hình
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)

model.train()
for epoch in range(3):  # 3 epochs để demo
    total_loss = 0
    for batch in train_loader:
        inputs = {k: v.to(device) for k, v in batch.items() if k != "labels"}
        labels = batch["labels"].to(device)
        outputs = model(**inputs, labels=labels)
        loss = outputs.loss
        total_loss += loss.item()
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    print(f"Epoch {epoch + 1}, Loss: {total_loss / len(train_loader)}")

# 9. Dự đoán trên dữ liệu mới
model.eval()
test_sentences = [
    "The company's shares soared after the merger announcement.",
    "Economic downturn led to massive layoffs in the sector.",
    "The market showed no significant change today."
]

predictions = []
label_map = {0: "negative", 1: "neutral", 2: "positive"}

with torch.no_grad():
    for sentence in test_sentences:
        context = f"Instruction: What is the sentiment of this news? Please choose an answer from {{negative/neutral/positive}}.\nInput: {sentence}\nAnswer: "
        inputs = tokenizer(
            context,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=128
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}
        outputs = model(**inputs)
        pred = torch.argmax(outputs.logits, dim=-1).item()
        predictions.append(label_map[pred])

# 10. In kết quả
print("\nTest Results:")
for sentence, pred in zip(test_sentences, predictions):
    print(f"News: {sentence}\nPredicted Sentiment: {pred}\n")

# 11. Đánh giá trên tập huấn luyện (để demo)
df["new_out"] = [change_target(pred) for pred in df["target"]]
df["new_target"] = df["target"].apply(change_target)
acc = accuracy_score(df["new_target"], df["new_out"])
f1 = f1_score(df["new_target"], df["new_out"], average="weighted")
print(f"Accuracy: {acc}, F1-Weighted: {f1}")